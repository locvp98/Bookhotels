package com.example.bookhotels.websecvice

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface Service {
    @GET("/dataroms")
    fun getdatakhachsan():Call<ResponseBody>

    @GET("/datahotels")
    fun getdatathanhpho():Call<ResponseBody>

    @GET("/datacomment/{hotelid}")
    fun getdatahotelsid(@Path("hotelid") hotelid:String):Call<ResponseBody>

    @POST("/login")
    fun PostLogin(@Field("email") email:String,
                    @Field("password") password: String
    ):Call<ResponseBody>

}