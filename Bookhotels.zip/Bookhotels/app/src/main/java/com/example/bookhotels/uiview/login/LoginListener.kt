package com.example.bookhotels.uiview.login

interface LoginListener {
    fun loginSuccess()
}