package com.example.bookhotels.uiview.alldiscovery

import com.example.bookhotels.dto.Hotels

interface Layhotelview {
    fun gethotel(hotelis:ArrayList<Hotels>)

}