package com.example.bookhotels.uiview.login

import android.content.Context

class LoginPresenter(context: Context, val loginView: LoginView):LoginListener {

    var loginModel = LoginModel(this)

    override fun loginSuccess() {

    }
}