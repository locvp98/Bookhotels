package com.example.bookhotels.uiview.login

import com.example.bookhotels.websecvice.Client
import okhttp3.ResponseBody
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginModel(val loginListener: LoginListener) {

    fun PostdataLogin(email:String,password:String){
        var call:Call<ResponseBody> = Client.getService()!!.PostLogin(email,password)
        call.enqueue(object:Callback<ResponseBody>{
            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
            }

            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                var jsonarr:JSONArray= JSONArray(response.body()!!.string())
                for (i in  0 until jsonarr.length()){
                    var jsonoop:JSONObject=jsonarr.getJSONObject(i)
                    var token=jsonoop.get("tokens")
                    loginListener.loginSuccess()
                }
            }

        })
    }
}