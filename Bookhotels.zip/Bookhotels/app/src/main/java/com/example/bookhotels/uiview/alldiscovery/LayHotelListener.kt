package com.example.bookhotels.uiview.alldiscovery

import com.example.bookhotels.dto.Hotels

interface LayHotelListener {
    fun getdatahotel(hotellist:ArrayList<Hotels>)
}