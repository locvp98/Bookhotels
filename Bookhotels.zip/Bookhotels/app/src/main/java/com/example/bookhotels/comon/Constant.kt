package com.example.bookhotels.comon

object Constant {
    val BASE_URL = "http://192.168.100.155:3000/"
}